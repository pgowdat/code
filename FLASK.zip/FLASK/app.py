from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit
import threading
import paramiko

app = Flask(__name__)
socketio = SocketIO(app)

# Dynamic variables for functions
context = {}

def CLI(ip, cmd, username, password, waitTime=10, retries=5):
    output = ""
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(ip, username=username, password=password, timeout=waitTime)

        stdin, stdout, stderr = ssh.exec_command(cmd)
        output = stdout.read().decode() + stderr.read().decode()
        ssh.close()
    except Exception as e:
        output = f"Error: {str(e)}"
    return type('obj', (object,), {'lastoutput': output})()

def add_drop_services_SLTE_RDtrib():
    global context
    mc_Start_Freq = int(context['lowFrequency'])
    n = int(context['n'])
    half_width = int(int(context['t_width']) / 2)

    cmds = []

    cmds.append(f"add degree-{context['degree_1']}")
    cmds.append(f"add modules-degree-{context['degree_1']}/1 supported-card card-{context['Aid_UT']}")
    cmds.append(f"set port-{context['Aid_UT']}-dwdm-line external-connectivity yes")
    cmds.append(f"set port-{context['Aid_UT']}-{context['ade']} external-connectivity yes")
    cmds.append("set -f amplifier amplifier-enable enabled")
    cmds.append(f"set -f ops-{context['Aid_UT']}-{context['ade']} role multi-carrier")

    mc_End_Freq = mc_Start_Freq + int(context['mc_width'])
    nmc_Center_freq = mc_Start_Freq + int(context['mc_nmc_guardband']) + half_width

    j = 1
    cmds.append(f"add mc-{context['Aid_UT']}-{context['ade']}-{j} lower-frequency {mc_Start_Freq} upper-frequency {mc_End_Freq} parent-oms {context['Aid_UT']}-dwdm-line")

    i = 0
    while i < n:
        cmds.append(f"add nmc-Line-{context['Aid_UT']}-{nmc_Center_freq}-{i+1} center-frequency {nmc_Center_freq} width {context['t_width']} parent-facility mc-{context['Aid_UT']}-{context['ade']}-{nmc_Center_freq}")
        cmds.append(f"add nmc-{context['Aid_UT']}-{context['ade']}-{nmc_Center_freq}-{i+1} center-frequency {nmc_Center_freq} width {context['t_width']} parent-facility oms-{context['Aid_UT']}-{context['ade']}")
        cmds.append(f"add oxcon-deg-1-{context['ade']}-CHM6-{nmc_Center_freq}-{i+1} source nmc-{context['Aid_UT']}-{context['ade']}-{nmc_Center_freq}-{i+1} destination nmc-Line-{context['Aid_UT']}-{nmc_Center_freq}-{i+1} direction two-way")

        i += 1
        nmc_Center_freq += int(context['nmc_nmc_guardband']) + int(context['t_width'])
        if (nmc_Center_freq + int(context['mc_nmc_guardband'])) >= mc_End_Freq:
            mc_Start_Freq = mc_End_Freq
            mc_End_Freq = mc_Start_Freq + int(context['mc_width'])
            j += 1
            cmds.append(f"add mc-{context['Aid_UT']}-{context['ade']}-{j} lower-frequency {mc_Start_Freq} upper-frequency {mc_End_Freq} parent-oms {context['Aid_UT']}-dwdm-line")
            nmc_Center_freq = mc_Start_Freq + int(context['mc_nmc_guardband']) + half_width

    for cmd in cmds:
        output = CLI(
            ip=context['ip'],
            cmd=cmd,
            username=context['username'],
            password=context['password']
        ).lastoutput
        socketio.emit('log', {'data': output})
        print(f"Running command: {cmd}")
        print(f"Output: {output}")

def add_drop_services_SLTE_cadtrib():
    global context
    print("Received context data:", context)
    mc_Start_Freq = int(context['lowFrequency'])
    n = int(context['n'])
    half_width = int(int(context['t_width']) / 2)

    cmds = []

    cmds.append(f"add card {context['cad_AID']}")
    cmds.append(f"set port-{context['cad_AID']}-{context['cad_ade']} external-connectivity yes")
    cmds.append(f"set -f ops-{context['cad_AID']}-{context['cad_ade']} role add-drop")

    cmds.append(f"add degree-{context['degree_1']}")
    cmds.append(f"add modules-degree-{context['degree_1']}/1 supported-card card-{context['Aid_UT']}")
    cmds.append(f"set port-{context['Aid_UT']}-dwdm-line external-connectivity yes")
    cmds.append(f"set port-{context['Aid_UT']}-{context['ade']} external-connectivity yes")
    cmds.append("set -f amplifier amplifier-enable enabled")
    cmds.append(f"set -f ops-{context['cad_AID']}-{context['cad_ade']} role multi-carrier")

    mc_End_Freq = mc_Start_Freq + int(context['mc_width'])
    nmc_Center_freq = mc_Start_Freq + int(context['mc_nmc_guardband']) + half_width

    j = 1
    cmds.append(f"add mc-{context['Aid_UT']}-{context['ade']}-{j} lower-frequency {mc_Start_Freq} upper-frequency {mc_End_Freq} parent-oms {context['Aid_UT']}-dwdm-line")

    i = 0
    while i < n:
        cmds.append(f"add nmc-Line-{context['Aid_UT']}-{nmc_Center_freq}-{i+1} center-frequency {nmc_Center_freq} width {context['t_width']} parent-facility mc-{context['Aid_UT']}-{context['ade']}-{nmc_Center_freq}")
        cmds.append(f"add nmc-CAD10-{context['cad_AID']}-{context['cad_ade']}-{nmc_Center_freq}-{i+1} center-frequency {nmc_Center_freq} width {context['t_width']} parent-facility oms-{context['cad_AID']}-{context['cad_ade']}")
        cmds.append(f"add oxcon-deg-1-{context['ade']}-{context['cad_ade']}-CHM6-{nmc_Center_freq}-{i+1} source nmc-CAD10-{context['cad_AID']}-{context['cad_ade']}-{nmc_Center_freq}-{i+1} destination nmc-Line-{context['Aid_UT']}-{nmc_Center_freq}-{i+1} direction two-way")

        i += 1
        nmc_Center_freq += int(context['nmc_nmc_guardband']) + int(context['t_width'])
        if (nmc_Center_freq + int(context['mc_nmc_guardband'])) >= mc_End_Freq:
            mc_Start_Freq = mc_End_Freq
            mc_End_Freq = mc_Start_Freq + int(context['mc_width'])
            j += 1
            cmds.append(f"add mc-{context['Aid_UT']}-{context['ade']}-{j} lower-frequency {mc_Start_Freq} upper-frequency {mc_End_Freq} parent-oms {context['Aid_UT']}-dwdm-line")
            nmc_Center_freq = mc_Start_Freq + int(context['mc_nmc_guardband']) + half_width

    for cmd in cmds:
        output = CLI(
            ip=context['ip'],
            cmd=cmd,
            username=context['username'],
            password=context['password']
        ).lastoutput
        socketio.emit('log', {'data': output})
        print(f"Running command: {cmd}")
        print(f"Output: {output}")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/run', methods=['POST'])
def run():
    global context
    data = request.json
    print("Received context data:", context)
    context = data
    func = data.get('function')

    # Validate mandatory fields
    mandatory_fields = ['ip', 'username', 'password', 'lowFrequency', 'n', 't_width',
                        'mc_width', 'mc_nmc_guardband', 'nmc_nmc_guardband', 'degree_1', 'Aid_UT', 'ade']

    if func == 'cadtrib':
        mandatory_fields += ['cad_AID', 'cad_ade']

    missing_fields = [field for field in mandatory_fields if not data.get(field)]

    if missing_fields:
        return jsonify({'status': f'Missing required fields: {", ".join(missing_fields)}'}), 400

    if func == 'RDtrib':
        thread = threading.Thread(target=add_drop_services_SLTE_RDtrib)
        thread.start()
        print("Running RDtrib function")
        return jsonify({'status': 'started RDtrib'})
    elif func == 'cadtrib':
        thread = threading.Thread(target=add_drop_services_SLTE_cadtrib)
        thread.start()
        print("Running CADtrib function")
        return jsonify({'status': 'started cadtrib'})
    else:
        return jsonify({'status': 'invalid function'})

    



if __name__ == '__main__':
    socketio.run(app, debug=True)